// ? EXERCISE 5: POLYMORPHISM

// Programming Technique II
// Semester 2, 2021/2022

// Section: 01
// Member 1's Name: DAYANG FARAH FARZANA BINTI ABANG IDHAM   Location: UTM Skudai
// Member 2's Name: FARRA NURZAHIN BT ZAHARIL ANUAR    Location: UTM SKUDAI

// Log the time(s) your pair programming sessions
//    Date          Time (From)     To       Duration (in minutes)
//  23 JUN 2024     1736            1920     67 minutes

// Video link:
// https://drive.google.com/file/d/1GxlTMMZ7mwhWT8AsmZCWGwf-pdM5_6HK/view?usp=drivesdk

#include <graphics.h>
#include <cmath>
#include <stdlib.h>
#include <time.h>

#include "shape.hpp"
#include "circle.hpp"
#include "rect.hpp"

#define COUNT 5

Shape *s[COUNT];
Shape *pointedShape = nullptr;

void listOfShape(int width, int height) {
    for (int i = 0; i < COUNT; i++) {
        int z = rand() % 2;
        int x = 1 + rand() % width;
        int y = 1 + rand() % height;

        if (z == 0) {
            int r = 20 + rand() % 120;
            s[i] = new Circle(x, y, r);
        } else {
            int w = 20 + rand() % 120;
            int h = 20 + rand() % 120;
            s[i] = new Rect(x, y, w, h);
        }
    }
}

void click() {
    int mx, my;

    if (ismouseclick(WM_LBUTTONDOWN)) {
        getmouseclick(WM_LBUTTONDOWN, mx, my);

        for (int i = 0; i < COUNT; i++) {
            if (s[i]->mouseClick(mx, my)) {
                if (pointedShape)
                    pointedShape->toggleSelected();

                pointedShape = s[i];
                pointedShape->toggleSelected();
                break;
            }
        }
    }
}

int main() {
    int width = getmaxwidth();    
    int height = getmaxheight();   

    initwindow(width, height, "Exercise 5");

    srand(time(NULL));
    listOfShape(width, height);

   
    for (int i = 0; i < COUNT; i++) {
        s[i]->draw();
    }

    char ch = 0;

    while (ch != 27) {  // ESC key
        if (kbhit()) {
            ch = getch();
            switch (toupper(ch)) {
                case '+':
                    if (pointedShape)
                        pointedShape->resize(5);  
                    break;

                case '-':
                    if (pointedShape)
                        pointedShape->resize(5);  
                    break;

                case KEY_LEFT:
                    if (pointedShape)
                        pointedShape->move(-10, 0);
                    break;

                case KEY_RIGHT:
                    if (pointedShape)
                        pointedShape->move(10, 0);
                    break;

                case KEY_UP:
                    if (pointedShape)
                        pointedShape->move(0, -10);
                    break;

                case KEY_DOWN:
                    if (pointedShape)
                        pointedShape->move(0, 10);
                    break;
            }
        }

        click(); 


    }

    for (int i = 0; i < COUNT; i++) {
        delete s[i];
    }

    return 0;
}