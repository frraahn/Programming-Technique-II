#ifndef CIRCLE_H
#define CIRCLE_H

#include "shape.hpp"

class Circle : public Shape {
private:
    int radius;

public:
    Circle(int _x = 0, int _y = 0, int _radius = 0);
    void draw() const override;
    void undraw() const override;
    void resize(double scale) override;
    bool mouseClick(int mx, int my) const override;
};

#endif