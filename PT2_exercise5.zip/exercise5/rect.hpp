#ifndef RECT_H
#define RECT_H

#include "shape.hpp"

class Rect : public Shape {
private:
    int width, height;

public:
    Rect(int _x = 0, int _y = 0, int _width = 0, int _height = 0);
    void draw() const override;
    void undraw() const override;
    void resize(double scale) override;
    bool mouseClick(int mx, int my) const override;
};

#endif