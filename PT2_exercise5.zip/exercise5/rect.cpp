#include <graphics.h>
#include "rect.hpp"

Rect::Rect(int _x, int _y, int _width, int _height) : width(_width), height(_height), Shape(_x, _y) {}

void Rect::draw() const {
    setcolor(selected ? YELLOW : WHITE);
    rectangle(x, y, x + width, y + height);
}

void Rect::undraw() const {
    setcolor(BLACK);
    rectangle(x, y, x + width, y + height);
}

void Rect::resize(double scale) {
    undraw();
    width = static_cast<int>(width * scale);   
    height = static_cast<int>(height * scale); 
    draw();
}

bool Rect::mouseClick(int mx, int my) const {
    return (mx >= x && mx <= x + width && my >= y && my <= y + height);
}